function refreshAuthDisplay() {
    var isLoggedIn = client.currentUser !== null;
    $("#logged-in").toggle(isLoggedIn);
    $("#logged-out").toggle(!isLoggedIn);

    if (isLoggedIn) {
        $("#login-name").text(client.currentUser.userId);
        console.log('we are logged in');
        //refreshTodoItems();
    }
}
function get() {
    var request = new XMLHttpRequest();
    request.open("GET", "https://averageweighttracker.azure-mobile.net/login/microsoftaccount", true);
    request.onreadystatechange = function() {
        if (request.readyState == 4) {
            if (request.status == 200 || request.status == 0) {
                alert(request.responseText);// -> request.responseText <- is a result
            }
        }
    }
    request.send();
}

var authapi = {
	    authorize: function(options) {
	    	var authUrl = 'https://accounts.google.com/o/oauth2/auth?' + $.param({
	    	    client_id: options.client_id,
	    	    redirect_uri: options.redirect_uri,
	    	    response_type: 'code',
	    	    scope: options.scope
	    	});

	    	var authWindow = window.open(authUrl, '_blank', 'location=no,toolbar=no');
	    	$(authWindow).on('loadstart', function(e) {
	    		  var url = e.originalEvent.url;
	    		  var code = /\?code=(.+)$/.exec(url);
	    		  var error = /\?error=(.+)$/.exec(url);

	    		  if (code || error) {
	    		    authWindow.close();
	    		  }

	    		  //TODO - exchange code for access token...
	    		  if (code) {
	    			  $.post('https://accounts.google.com/o/oauth2/token', {
	    			    code: code[1],
	    			    client_id: options.client_id,
	    			    client_secret: options.client_secret,
	    			    redirect_uri: options.redirect_uri,
	    			    grant_type: 'authorization_code'
	    			  }).done(function(data) {
	    			    deferred.resolve(data);
	    			  }).fail(function(response) {
	    			    deferred.reject(response.responseJSON);
	    			  });
	    			} else if (error) {
	    			  deferred.reject({
	    			    error: error[1]
	    			  });
	    			}
	    		});
	    }
};

function logIn() {

	//var popup = window.open("https://averageweighttracker.azure-mobile.net/login/facebook"); // option token if already gotten
	//console.log(popup.location);
	//repeat(popup);
	var $loginStatus = $('#logged-out p');
	authapi.authorize({
	      client_id: '316339286311-ihvnohodocdnno3li452ii8guftegjqh.apps.googleusercontent.com',
	      client_secret: 'IgU62BqeOPVrQCfw2RRUf4C7',
	      redirect_uri: 'https://localhost',
	      scope: 'openid email'
	    }).done(function(data) {
	      $loginStatus.html('Access Token: ' + data.access_token);
	    }).fail(function(data) {
	      $loginStatus.html(data.error);
	    });
	
	//client.login("facebook").then(refreshAuthDisplay, function (error) {
    //    alert(error);
    //});
}

function logOut() {
    client.logout();
    refreshAuthDisplay();
    //$('#summary').html('<strong>You must login to access data.</strong>');
}

