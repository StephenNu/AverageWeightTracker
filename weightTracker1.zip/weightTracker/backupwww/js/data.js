var averagesList = [];
var weightsList = [];
var averagesIDs = [];
var weightsIDs = [];
var current = [new dataline(
                            "rgba(214,32,32,0)",
                            "rgba(220,220,220,0)",
                            "rgba(220,220,220,0)",
                            "#fff",
                            []
                            )
              ]
;
var resizing = false;

var client = null;